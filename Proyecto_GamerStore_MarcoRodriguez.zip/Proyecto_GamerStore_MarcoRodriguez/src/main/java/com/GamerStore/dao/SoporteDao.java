
package com.GamerStore.dao;

import com.GamerStore.domain.Soporte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SoporteDao extends JpaRepository<Soporte, Long>{
    
}
